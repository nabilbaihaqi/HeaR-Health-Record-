-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 29 Jun 2017 pada 03.34
-- Versi Server: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mujahid`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `doctor`
--

CREATE TABLE `doctor` (
  `id_doc` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `specialize` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `doctor`
--

INSERT INTO `doctor` (`id_doc`, `name`, `date`, `email`, `pass`, `address`, `specialize`, `image`) VALUES
(3, 'suyanto', '2017-06-27', 's@gmail.com', 'b', 'Gondangdiah', 'GIGI', 'images/D1.jpg'),
(4, 'abi', '0000-00-00', 'abi@gmail.com', '12345', 'bogor', 'jantung', 'images/Logo HIMALKOM.jpg'),
(10, 'as', '2017-06-02', 'as@gmail.com', 'as', 'as', 'jantung', 'images/D4.jpg'),
(11, 'ko', '2017-06-23', 'ko@gmail.com', 'ko', 'ko', 'kandungan', 'images/D5.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `message`
--

CREATE TABLE `message` (
  `id_message` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `id_doc` int(11) NOT NULL,
  `message` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `message`
--

INSERT INTO `message` (`id_message`, `id`, `id_doc`, `message`, `timestamp`) VALUES
(1, 1, 3, 'tesss', '0000-00-00 00:00:00'),
(2, 1, 3, 'gdghdhfx', '0000-00-00 00:00:00'),
(3, 1, 3, 'kkkk', '0000-00-00 00:00:00'),
(4, 1, 3, 'hallo', '0000-00-00 00:00:00'),
(5, 1, 3, 'aaaaaaaaaaaaaaaaaaaaaaaaaa', '0000-00-00 00:00:00'),
(6, 1, 3, 'byuyuuuu', '0000-00-00 00:00:00'),
(7, 1, 3, 'aaaaaahgjhgjh', '0000-00-00 00:00:00'),
(8, 1, 3, 'aaaaa', '0000-00-00 00:00:00'),
(9, 1, 3, 'jgggfdd', '0000-00-00 00:00:00'),
(10, 1, 3, 'apa?', '0000-00-00 00:00:00'),
(11, 0, 10, 'coba sebutkan?', '0000-00-00 00:00:00'),
(12, 0, 3, 'mmmm', '0000-00-00 00:00:00'),
(13, 2, 0, 'asagfdhgkjsafhkjsgtjtg', '0000-00-00 00:00:00'),
(14, 2, 0, 'gjerhjrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pasien`
--

CREATE TABLE `pasien` (
  `id` int(255) NOT NULL,
  `id_doc` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pasien`
--

INSERT INTO `pasien` (`id`, `id_doc`, `name`, `date`, `email`, `pass`, `address`, `image`) VALUES
(1, 3, 'abi', '2017-06-08', 'abi@gmail.com', 'abi', 'Bogor', 'images/Logo IPB.png'),
(2, 0, 'lili', '2017-06-01', 'lili@gmail.com', '123456', 'bara', 'images/b.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `skd`
--

CREATE TABLE `skd` (
  `Id_skd` int(25) NOT NULL,
  `image` varchar(255) NOT NULL,
  `id_doc` int(25) NOT NULL,
  `id` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`id_doc`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id_message`);

--
-- Indexes for table `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `id_doc` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id_message` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `pasien`
--
ALTER TABLE `pasien`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
