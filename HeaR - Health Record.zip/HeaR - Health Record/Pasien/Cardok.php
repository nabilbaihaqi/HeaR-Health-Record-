<!DOCTYPE html>
<?php
include 'connect.php';
$id = $_SESSION['id'];
 ?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Health Record</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="assets/css/zabuto_calendar.css">
    <link rel="stylesheet" type="text/css" href="assets/js/gritter/css/jquery.gritter.css" />
    <link rel="stylesheet" type="text/css" href="assets/lineicons/style.css">

    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

    <script src="assets/js/chart-master/Chart.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

  <section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a href="index.html" class="logo"><b>HEALTH RECORD</b></a>
            <!--logo end-->

            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="awal.php">Logout</a></li>
            	</ul>
            </div>
        </header>
      <!--header end-->

      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
                <?php
                  $query = mysqli_query($conn,"SELECT * from pasien WHERE id = '$id'");
                  $row = mysqli_fetch_array($query);
                ?>
                  <p class="centered"><a href="Profile.php"><img src="<?php echo $row['image']; ?>" class="img-circle" width="90"></a></p>
                  <h5 class="centered"><?php echo $row['name']; ?></h5>

                  <li class="sub-menu">
                      <a href="Profile.php" >
                          <i class="fa fa-desktop"></i>
                          <span>Profile</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a class="active" href="Cardok.php">
                          <i class="fa fa-cogs"></i>
                          <span>Cari Dokter</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="dokterku.php" >
                          <i class="fa fa-book"></i>
                          <span>Dokterku</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="konsultasi.php" >
                          <i class="fa fa-tasks"></i>
                          <span>Konsultasi</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="cttdok.php" >
                          <i class="fa fa-th"></i>
                          <span>Catatan Dokter</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="skets.php" >
                          <i class=" fa fa-bar-chart-o"></i>
                          <span>Surat Keterangan Sehat</span>
                      </a>
                  </li>

              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->

      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
          	<h3><i class="fa fa-angle-right"></i> Cari Dokter</h3>

            <div class="row mt">
              <?php
              $query = mysqli_query($conn,"SELECT * FROM doctor");
              while($row = mysqli_fetch_array($query) ) {
                ?>
    					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 desc">
                <div class="showback">
    						<div class="project-wrapper">
    		                    <div class="project">
    		                        <div class="photo-wrapper">
    		                            <div class="photo">
    		                            	<a class="fancybox" href="dok_dok.php?id=<?php echo $row['id_doc']; ?>"><img class="img-responsive" src="<?php echo $row['image']; ?>" alt=""></a>
    		                            </div>
    		                            <div class="overlay"></div>
    		                        </div>
    		                    </div>
    		                </div>
                      </div>
    					</div><!-- col-lg-4 -->

              <?php } ?>


    				</div><!-- /row -->

              <!-- page end-->
		</section><! --/wrapper -->
      </section><!-- /MAIN CONTENT -->

      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="assets/js/fullcalendar/fullcalendar.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>


    <!--common script for all pages-->
    <script src="assets/js/common-scripts.js"></script>

    <!--script for this page-->
	<script src="assets/js/calendar-conf-events.js"></script>

  <script>
      //custom select box

      $(function(){
          $("select.styled").customSelect();
      });

  </script>

  </body>
</html>
