<?php
  $conn = mysqli_connect('localhost','root','','mujahid')
  or die ("Connection Failed".mysqli_error());

  session_start();
?>
