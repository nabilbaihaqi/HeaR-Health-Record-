<?php
  include "connect.php";

  $keluhan = $_POST['keluhan'];

  $id = $_SESSION['id'];
  $query     = mysqli_query($conn, "SELECT * FROM pasien WHERE id = '$id'");
  $result    = mysqli_fetch_array($query);

  $id_doc = $result['id_doc'];
  $time = time();

  $sql_konsul = "INSERT INTO message(id_message,id,id_doc,message,timestamp)
                  VALUE('', '$id', '$id_doc', '$keluhan', '$time')";
  $hasil=mysqli_query($conn, $sql_konsul);

  if($hasil){
?>
  <script languange="javascript">alert("konsultasi sukses!");</script>
  <script>document.location.href='konsultasi.php';</script>
<?php
  }
  else{
?>
    <script languange="javascript">alert("konsultasi gagal!");</script>
    <script>document.location.href='../homepage/profil-dokter.php';</script>
<?php
  }
 ?>
