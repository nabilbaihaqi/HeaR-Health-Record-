<?php
      include 'connect.php';

      if(isset($_POST['submit'])){
        $nama   = $_POST['nama'];
        $email  = $_POST['email'];
        $birth  = $_POST['birth'];
        $pass   = $_POST['pass'];
        $alamat = $_POST['alamat'];
        $spesialis = $_POST['spesialis'];

        $target = "images/".basename($_FILES['image']['name']);
        $image = $_FILES['image']['name'];

        $query = mysqli_query($conn,"INSERT INTO doctor
                                (name,date,email,pass,address,specialize,image) VALUES
                                  ('$nama','$birth','$email','$pass','$alamat','$spesialis','images/$image')
                                ");
        move_uploaded_file($_FILES['image']['tmp_name'],"$target");
        if($query){
          echo "BERHASIL MASUKIN DATA </br>";
          $query3 = mysqli_query($conn,"SELECT * FROM doctor WHERE email = '$email'");
          $row = mysqlI_fetch_array($query3);
          $_SESSION['id_doc'] = $row['id_doc'];
          ?>

          <a href="dprofile.php?id=<?php echo $row['id_doc'] ?>">Doktor</a>
        <?php } else {
          echo "gamvar ghaghallll.";
      }
    }
?>
