<?php
  include 'connect.php';

  if(isset($_POST['email'])){
  $email  = $_POST['email'];
  $pass   = $_POST['pass'];
  $query = mysqli_query($conn, "SELECT * FROM pasien WHERE email='$email' and pass='$pass'");
  $row = mysqli_fetch_array($query);
  if ($row) {
    
  $_SESSION['id'] = $row['id'];
    $_SESSION['status'] = "pasien";

?>
      <script language="javascript">alert("Login Succesful"); </script>
      <script>document.location.href='../Pasien/Profile.php'; </script>
      <!-- echo "<meta http-equiv='refresh' conten='0; url=Profile.php?email=<?php echo $email;?>'>" -->
<?php
  }
  else {
?>
    <script language="javascript">alert("Login Failed"); </script>
    <script>document.location.href='../Pasien/login.php';</script>
<?php
  }

}
  mysqli_close($conn);
?>
