<?php
  include "connect.php";

  $keluhan = $_POST['keluhan'];

  $id_doc = $_SESSION['id_doc'];
  $query     = mysqli_query($conn, "SELECT * FROM doctor WHERE id_doc = '$id_doc'");
  $result    = mysqli_fetch_array($query);

  $id = $result['id'];
  $time = time();

  $sql_konsul = "INSERT INTO message(id_message,id,id_doc,message,timestamp)
                  VALUE('', '$id', '$id_doc', '$keluhan', '$time')";
  $hasil=mysqli_query($conn, $sql_konsul);

  if($hasil){
?>
  <script languange="javascript">alert("konsultasi sukses!");</script>
  <script>document.location.href='dkonsultasi.php';</script>
<?php
  }
  else{
?>
    <script languange="javascript">alert("konsultasi gagal!");</script>
    <script>document.location.href='dkonsultasi.php';</script>
<?php
  }
 ?>
