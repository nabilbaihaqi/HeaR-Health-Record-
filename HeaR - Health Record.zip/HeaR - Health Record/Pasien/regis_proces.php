<?php
      include 'connect.php';

      if(isset($_POST['submit'])){
        $nama   = $_POST['nama'];
        $email  = $_POST['email'];
        $birth  = $_POST['birth'];
        $pass   = $_POST['pass'];
        $alamat = $_POST['alamat'];

        $target = "images/".basename($_FILES['image']['name']);
        $image = $_FILES['image']['name'];

        $query = mysqli_query($conn,"INSERT INTO pasien
                                (name,date,email,pass,address,image) VALUES
                                  ('$nama','$birth','$email','$pass','$alamat','images/$image')
                                ");
        move_uploaded_file($_FILES['image']['tmp_name'],"$target");
        if($query){

          echo "BERHASIL MASUKIN DATA </br>";
          $query3 = mysqli_query($conn,"SELECT * FROM pasien WHERE email = '$email'");
          $row = mysqli_fetch_array($query3);
          $_SESSION['id'] = $row['id'];
          ?>

          <a href="Profile.php?id=<?php echo $row['id'] ?>">Pasien</a>
        <?php } else {
          echo "gamvar ghaghallll.";
      }
    }
?>
