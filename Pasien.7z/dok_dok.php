<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>HeaR-Healt Record</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="assets/css/zabuto_calendar.css">
    <link rel="stylesheet" type="text/css" href="assets/js/gritter/css/jquery.gritter.css" />
    <link rel="stylesheet" type="text/css" href="assets/lineicons/style.css">

    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

    <script src="assets/js/chart-master/Chart.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

  <section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a href="index.html" class="logo"><b>HEALT RECORD</b></a>
            <!--logo end-->

            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="login.php">Logout</a></li>
            	</ul>
            </div>
        </header>
      <!--header end-->

      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">

                  <p class="centered"><a href="profile.html"><img src="assets/img/user.png" class="img-circle" width="90"></a></p>
                  <h5 class="centered">Healt Record</h5>

                  <li class="sub-menu">
                      <a href="Profile.php" >
                          <i class="fa fa-desktop"></i>
                          <span>Profile</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a class="active" href="Cardok.php">
                          <i class="fa fa-cogs"></i>
                          <span>Cari Dokter</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="dokterku.php" >
                          <i class="fa fa-book"></i>
                          <span>Dokterku</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="konsultasi.php" >
                          <i class="fa fa-tasks"></i>
                          <span>Konsultasi</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="cttdok.php" >
                          <i class="fa fa-th"></i>
                          <span>Catatan Dokter</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="skets.php" >
                          <i class=" fa fa-bar-chart-o"></i>
                          <span>Surat Keterangan Sehat</span>
                      </a>
                  </li>

              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->

      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
          	<h3><i class="fa fa-angle-right"></i> Cari Dokter</h3>

            <div class="row mt">

    					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 desc">
                <div class="showback">
    						<div class="project-wrapper">
    		                    <div class="project">
    		                        <div class="photo-wrapper">
    		                            <div class="photo">
    		                            	<a class="fancybox" href="assets/img/portfolio/port04.jpg"><img class="img-responsive" src="assets/img/D1.jpg" alt=""></a>
    		                            </div>
    		                            <div class="overlay"></div>
    		                        </div>
    		                    </div>
    		                </div>
                        </div>
                        <button class="btn btn-success btn-lg">
            						  Tambakan Dokter
            						</button>
    					</div><!-- col-lg-4 -->
              <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12 desc">
                <! -- ALERTS EXAMPLES -->
                <div class="showback">
                  <h5><i class="fa fa-angle-right"></i> Nama Lengkap</h5>
                <div class="alert alert-success"><b> -</b> </div>
                 <h5><i class="fa fa-angle-right"></i> Spesialisasi</h5>
                <div class="alert alert-info"><b></b> -</div>
                 <h5><i class="fa fa-angle-right"></i> Birth</h5>
                <div class="alert alert-warning"><b> -</b> </div>
                <h5><i class="fa fa-angle-right"></i> E-mail </h5>
                <div class="alert alert-danger"><b> -</b></div>
                <h5><i class="fa fa-angle-right"></i> Alamat  </h5>
                <div class="alert alert-info"><b> -</b></div>
                <h5><i class="fa fa-angle-right"></i> No. Hp</h5>
                <div class="alert alert-info"><b> -</b></div>
                <div class="form-group">
                    <label>Text area</label>
                    <textarea class="form-control" rows="3"></textarea>
                </div>
                </div><!-- /showback -->
                </div>
    				</div><!-- /row -->
              <br>


              <!-- page end-->
		</section><! --/wrapper -->
      </section><!-- /MAIN CONTENT -->

      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="assets/js/fullcalendar/fullcalendar.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>


    <!--common script for all pages-->
    <script src="assets/js/common-scripts.js"></script>

    <!--script for this page-->
	<script src="assets/js/calendar-conf-events.js"></script>

  <script>
      //custom select box

      $(function(){
          $("select.styled").customSelect();
      });

  </script>

  </body>
</html>
