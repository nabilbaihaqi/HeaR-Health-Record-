<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HeaR</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="assets/css/bootstrap (3).css" rel="stylesheet">
<link href="assets/css/style (2).css" rel="stylesheet">
<link rel='stylesheet' id='prettyphoto-css'  href="assets/css/prettyPhoto.css" type='text/css' media='all'>
<link href="assets/css/fontello.css" type="text/css" rel="stylesheet">
<!--[if lt IE 7]>
<link href="css/fontello-ie7.css" type="text/css" rel="stylesheet">
<![endif]-->
<link href='http://fonts.googleapis.com/css?family=Quattrocento:400,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Patua+One' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<style type="text/css">
body {
	padding-top: 60px; /* 60px to make the container go all the way to the bottom of the topbar */
}
</style>
<link href="assets/css/bootstrap-responsive.css" rel="stylesheet">
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<![endif]-->
<script src="assets/js/jquery (2).js"></script>
<script src="assets/js/jquery.scrollTo-1.4.2-min.js"></script>
<script src="assets/js/jquery.localscroll-1.2.7-min.js"></script>
<script charset="utf-8">
$(document).ready(function () {
    $("a[rel^='prettyPhoto']").prettyPhoto();
});
</script>
</head>
<body>
<div class="navbar-wrapper">
  <div class="navbar navbar-inverse navbar-fixed-top">
    <div class="navbar-inner">
      <div class="container"> <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </a>
        <h1 class="brand"><a href="#top">Healt Record!</a></h1>
        <nav class="pull-right nav-collapse collapse">
          <ul id="menu-main" class="nav">
            <li><a href="dlogin.php">Dokter</a></li>
            <li><a href="login.php">Pasien</a></li>
						<li><a title="services" href="#services">Services</a></li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
</div>
<div id="top"></div>
<div id="headerwrap">
  <header class="clearfix">
    <h1><span>HeaR!</span> Mari bergabung bersama kami!</h1>
    <div class="container">
      <div class="row">
        <div class="span12">
          <input type="text" name="your-email" placeholder="Assalamualaikum ..." class="cform-text" size="40" title="your email">
          <input type="submit" href="gmail.com" value="Send" class="cform-submit">
        </div>
      </div>
      <div class="row">
        <div class="span12">
          <ul class="icon">
            <li><a href="#"><i class="icon-pinterest-circled"></i></a></li>
            <li><a href="#"><i class="icon-facebook-circled"></i></a></li>
            <li><a href="#"><i class="icon-twitter-circled"></i></a></li>
            <li><a href="#"><i class="icon-gplus-circled"></i></a></li>
            <li><a href="#"><i class="icon-skype-circled"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </header>
</div>
<div class="scrollblock">
  <section id="feature">
    <div class="container">
      <div class="row">
        <div class="span12">
          <article>
            <p>Salah satu media yang mempermudah</p>
            <p>masyarakat untuk mendapatkan pelayanan kesehatan</p>
            <p>secara menyeluruh dan terjangkau.</p>
          </article>
        </div>
      </div>
    </div>
  </section>
</div>
<hr>
<section id="services" class="single-page scrollblock">
  <div class="container">
    <div class="align"><i class="icon-cog-circled"></i></div>
    <h1>Mengapa harus Healt Record?</h1>
    <div class="row">
      <div class="span3">
        <div class="align"> <i class="icon-desktop sev_icon"></i></div>
        <h2>Simple</h2>
        <p>Pasien tanpa harus pergi ke rumah sakit atau puskesmas.</p>
      </div>
      <div class="span3">
        <div class="align"> <i class="icon-vector sev_icon"></i></div>
        <h2>Collaborative</h2>
        <p>Pasien dapat berkonsultasi tentang kesehatannya dan dokter memberikan hasil diagnosa.</p>
      </div>
      <div class="span3">
        <div class="align"> <i class="icon-basket sev_icon"></i></div>
        <h2>Terintegrasi</h2>
        <p>Bekerjasama dengan dokter yang memiliki SK.</p>
      </div>
      <div class="span3">
        <div class="align"> <i class="icon-mobile-1 sev_icon"></i></div>
        <h2>Everywhere</h2>
        <p>Konsultasi bisa dilakukan dimanapun dan kapanpun.</p>
      </div>
    </div>
  </div>
</section>
<hr>
<section id="testimonials" class="single-page hidden-phone">
  <div class="container">
    <div class="row">
      <div class="blockquote-wrapper">
        <blockquote class="mega">
          <div class="span4">
            <p class="cite">-Unknow :</p>
          </div>
          <div class="span8">
            <p class="alignright">"Kesehatan adalah budaya hidup sehat. Penyakit adalah meninggalkan budaya hidup sehat."</p>
          </div>
        </blockquote>
      </div>
    </div>
  </div>
</section>
<hr>
<div class="footer-wrapper">
  <div class="container">
    <footer> <small>&copy; 2017 - Healt Record</small> </footer>
  </div>
</div>
<script src="assets/js/bootstrap.js"></script>
<script src="assets/js/jquery.prettyPhoto.js"></script>
<script src="assets/js/site.js"></script>
</body>
</html>
